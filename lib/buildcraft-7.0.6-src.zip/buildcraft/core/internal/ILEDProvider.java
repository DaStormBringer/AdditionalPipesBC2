package buildcraft.core.internal;

public interface ILEDProvider {
	int getLEDLevel(int led);
}
