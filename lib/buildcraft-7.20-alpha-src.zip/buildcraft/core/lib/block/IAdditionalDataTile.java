package buildcraft.core.lib.block;

public interface IAdditionalDataTile {
    void sendNetworkUpdate();
}
