package buildcraft.core.lib;

public interface IEnergyChangeListener {
    void onEnergyChange(int oldEnergy, int newEnergy);
}
