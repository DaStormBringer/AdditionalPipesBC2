package buildcraft.api.transport.gate;

import buildcraft.api.transport.ObjectDefinition;

public final class GateAddonDefinition extends ObjectDefinition {
    public GateAddonDefinition(String tag) {
        super(tag);
    }
}
