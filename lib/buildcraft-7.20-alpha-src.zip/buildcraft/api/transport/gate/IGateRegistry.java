package buildcraft.api.transport.gate;

import buildcraft.api.IDoubleRegistry;

public interface IGateRegistry extends IDoubleRegistry<GateDefinition> {}
