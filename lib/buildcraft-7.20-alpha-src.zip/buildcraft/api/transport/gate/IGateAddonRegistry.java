package buildcraft.api.transport.gate;

import buildcraft.api.IDoubleRegistry;

public interface IGateAddonRegistry extends IDoubleRegistry<GateAddonDefinition> {}
