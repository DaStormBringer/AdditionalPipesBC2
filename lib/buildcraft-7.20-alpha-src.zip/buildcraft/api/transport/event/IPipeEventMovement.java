package buildcraft.api.transport.event;

public interface IPipeEventMovement extends IPipeEvent {
    IPipeContentsEditable getContents();
}
