package buildcraft.api.transport.event;

import buildcraft.api.transport.IPipe;

public interface IPipeEvent {
    IPipe getPipe();
}
