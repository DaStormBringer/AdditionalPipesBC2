package buildcraft.api.transport.event;

/** Fired whenever a player right clicks a pipe with no held item (an empty hand) */
public interface IPipeEventPlayerActivate extends IPipeEventPlayerInteract {}
