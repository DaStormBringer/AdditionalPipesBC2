package buildcraft.api.transport.event;

/** Fired every tick from the world thread. */
public interface IPipeEventTick extends IPipeEvent {}
