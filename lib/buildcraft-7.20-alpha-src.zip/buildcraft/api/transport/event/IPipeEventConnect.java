package buildcraft.api.transport.event;

/** Fired when a connection is made to another block. */
public interface IPipeEventConnect extends IPipeEventConnection {}
