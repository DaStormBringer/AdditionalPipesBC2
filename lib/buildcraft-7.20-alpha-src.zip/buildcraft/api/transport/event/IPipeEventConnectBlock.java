package buildcraft.api.transport.event;

/** Fired whenever this connects to a block that is NOT a pipe. */
public interface IPipeEventConnectBlock extends IPipeEventConnect {}
