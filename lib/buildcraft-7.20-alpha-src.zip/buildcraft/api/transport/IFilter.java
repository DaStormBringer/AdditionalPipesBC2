package buildcraft.api.transport;

public interface IFilter {

}
