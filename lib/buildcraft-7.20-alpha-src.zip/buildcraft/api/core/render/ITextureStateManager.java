package buildcraft.api.core.render;

import net.minecraft.client.renderer.texture.TextureAtlasSprite;

public interface ITextureStateManager {
    void set(TextureAtlasSprite icon);
}
