@API(apiVersion = "1.0", owner = "BuildCraftAPI|core", provides = "BuildCraftAPI|mj")
package buildcraft.api.mj;

import net.minecraftforge.fml.common.API;
