package buildcraft.api.enums;

public enum EnumInventoryDirection {
    ABOVE,
    BELOW,
    LEFT,
    RIGHT,
    UNKNOWN;
}
