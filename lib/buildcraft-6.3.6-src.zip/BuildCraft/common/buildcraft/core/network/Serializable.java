package buildcraft.core.network;

import io.netty.buffer.ByteBuf;

import buildcraft.api.core.ISerializable;

public class Serializable implements ISerializable {
	@Override
	public void readData(ByteBuf stream) {

	}

	@Override
	public void writeData(ByteBuf stream) {

	}
}
