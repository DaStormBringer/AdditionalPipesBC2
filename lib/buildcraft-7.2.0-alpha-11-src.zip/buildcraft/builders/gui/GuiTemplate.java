package buildcraft.builders.gui;

import buildcraft.core.blueprints.BlueprintBase;

public class GuiTemplate extends GuiBlueprintBase {
    public GuiTemplate(BlueprintBase blueprint) {
        super(blueprint);
    }
}
