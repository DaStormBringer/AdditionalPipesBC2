package buildcraft.builders.gui;

import buildcraft.core.blueprints.BlueprintBase;

public class GuiBlueprint extends GuiBlueprintBase {
    public GuiBlueprint(BlueprintBase blueprint) {
        super(blueprint);
    }
}
