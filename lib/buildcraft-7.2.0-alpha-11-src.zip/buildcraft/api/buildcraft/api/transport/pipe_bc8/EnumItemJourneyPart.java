package buildcraft.api.transport.pipe_bc8;

public enum EnumItemJourneyPart {
    JUST_ENTERED,
    TO_CENTER,
    FROM_CENTER;
}
