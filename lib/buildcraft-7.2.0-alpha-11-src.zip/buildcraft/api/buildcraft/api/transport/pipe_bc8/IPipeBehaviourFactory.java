package buildcraft.api.transport.pipe_bc8;

public interface IPipeBehaviourFactory {
    PipeBehaviour_BC8 createNew(IPipe_BC8 pipe);
}
