package buildcraft.api.transport.pipe_bc8;

import buildcraft.api.core.INBTLoadable_BC8;
import buildcraft.api.core.INetworkLoadable_BC8;

public interface IPluggable_BC8 extends INetworkLoadable_BC8<IPluggable_BC8>, INBTLoadable_BC8<IPluggable_BC8> {

}
