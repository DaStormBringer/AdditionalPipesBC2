package buildcraft.api.transport.pipe_bc8;

/**
 * 
 */
public interface IPipeAddonItem {

}
