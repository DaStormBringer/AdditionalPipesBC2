package buildcraft.core.lib.event;

public class HandlerGenerator {

}
