package buildcraft.api.filler;

public final class FillerManager {
    public static IFillerRegistry registry;
}
