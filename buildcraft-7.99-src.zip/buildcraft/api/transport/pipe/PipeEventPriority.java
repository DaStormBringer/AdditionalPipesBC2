package buildcraft.api.transport.pipe;

public enum PipeEventPriority {
    PRE,
    NORMAL,
    POST
}
