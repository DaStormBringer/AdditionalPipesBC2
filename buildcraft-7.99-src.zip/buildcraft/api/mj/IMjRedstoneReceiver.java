package buildcraft.api.mj;

/** Designates that a receiver can receive redstone power (cheap, free, small amounts) */
public interface IMjRedstoneReceiver extends IMjReceiver {}
