package buildcraft.api.core;

public interface IEngineType {
    String getItemModelLocation();
}
